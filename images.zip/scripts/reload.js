function reload(doc, arr) {
    doc.innerHTML = '';
    for (let i of arr) {
        doc.innerHTML += `
            <div class="product">
                <img src="${i.image}" alt="">
                <div class="product__info">
                    <h3>${i.title.slice(0, 50)}...</h3>
                    <p>${i.description.slice(0, 200)}...</p>
                    <div class="ratings">
                        <div class="price">
                            <img src="./Group 7.png" alt="">
                            <span>${i.price}</span>
                        </div>
                        <div class="mark">
                            <img src="./Group 10.png" alt="">
                            <span>${i.rating.rate}</span>
                        </div>
                        <div class="count">
                            <img src="./Group 9.png" alt="">
                            <span>${i.rating.count}</span>
                        </div>
                    </div>
                    <button>В избранное</button>
                </div> 
            </div>
        `
    }
}